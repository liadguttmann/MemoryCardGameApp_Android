package com.example.user.memorycardgameapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import java.util.Arrays;
import java.util.Collections;


public class GameLogicActivity extends Activity {

    TextView points_p1 , points_p2;
    ImageView iv_11, iv_12 , iv_13, iv_14,iv_21, iv_22 , iv_23, iv_24,iv_31, iv_32 , iv_33, iv_34;
    RadioButton yellow , green , blue , white , red;
    Integer [] CardsCollection = {11, 12, 13, 14, 15, 16, 21, 22, 23, 24, 25, 26};
    LinearLayout mainLayout;
    MediaPlayer successSong , winnerSong, failSong ;

    int image11, image12,image13,image14,image15,image16, image21, image22,image23,image24,image25,image26;
    int firstCard , secondCard;
    int firstClick , secondClick;
    int cardNumber = 1;
    int turn = 1;

    int firstPlayerPoints = 0 , secondPlayerPoints = 0;

    String player1 ,player2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_logic);

        player1 = getString(R.string.player1_textview);
        player2 = getString(R.string.player2_textview);

        mainLayout = findViewById(R.id.mainLayout);
        yellow = findViewById(R.id.yellowBG);
        green = findViewById(R.id.greenBG);
        blue = findViewById(R.id.blueBG);
        red = findViewById(R.id.redBG);
        white = findViewById(R.id.whiteBG);

        successSong = MediaPlayer.create(GameLogicActivity.this , R.raw.success);
        winnerSong = MediaPlayer.create(GameLogicActivity.this , R.raw.winner);
        failSong = MediaPlayer.create(GameLogicActivity.this , R.raw.fail);

        yellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainLayout.setBackgroundColor(getResources().getColor(R.color.yellowColor));
            }
        });
        green.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainLayout.setBackgroundColor(getResources().getColor(R.color.greenColor));
            }
        });
        blue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainLayout.setBackgroundColor(getResources().getColor(R.color.blueColor));
            }
        });
        red.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainLayout.setBackgroundColor(getResources().getColor(R.color.redColor));
            }
        });
        white.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainLayout.setBackgroundColor(getResources().getColor(R.color.whiteColor));
            }
        });


        points_p1 = findViewById(R.id.points_p1);
        points_p2 = findViewById(R.id.points_p2);

        iv_11 = findViewById(R.id.iv_11);
        iv_12 = findViewById(R.id.iv_12);
        iv_13 = findViewById(R.id.iv_13);
        iv_14 = findViewById(R.id.iv_14);
        iv_21 = findViewById(R.id.iv_21);
        iv_22 = findViewById(R.id.iv_22);
        iv_23 = findViewById(R.id.iv_23);
        iv_24 = findViewById(R.id.iv_24);
        iv_31 = findViewById(R.id.iv_31);
        iv_32 = findViewById(R.id.iv_32);
        iv_33 = findViewById(R.id.iv_33);
        iv_34 = findViewById(R.id.iv_34);

        iv_11.setTag("0");
        iv_12.setTag("1");
        iv_13.setTag("2");
        iv_14.setTag("3");
        iv_21.setTag("4");
        iv_22.setTag("5");
        iv_23.setTag("6");
        iv_24.setTag("7");
        iv_31.setTag("8");
        iv_32.setTag("9");
        iv_33.setTag("10");
        iv_34.setTag("11");

        frontOfCardResource();
        Collections.shuffle(Arrays.asList(CardsCollection));

        points_p2.setTextColor(Color.GRAY);

        iv_11.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                int Card = Integer.parseInt((String)view.getTag());
                doStuff(iv_11, Card);
            }});

        iv_12.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                int Card = Integer.parseInt((String)view.getTag());
                doStuff(iv_12, Card);
            }});
        iv_13.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                int Card = Integer.parseInt((String)view.getTag());
                doStuff(iv_13, Card);
            }});
        iv_14.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                int Card = Integer.parseInt((String)view.getTag());
                doStuff(iv_14, Card);
            }});

        iv_21.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                int Card = Integer.parseInt((String)view.getTag());
                doStuff(iv_21, Card);
            }});
        iv_22.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                int Card = Integer.parseInt((String)view.getTag());
                doStuff(iv_22, Card);
            }});
        iv_23.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                int Card = Integer.parseInt((String)view.getTag());
                doStuff(iv_23, Card);
            }});
        iv_24.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                int Card = Integer.parseInt((String)view.getTag());
                doStuff(iv_24, Card);
            }});

        iv_31.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                int Card = Integer.parseInt((String)view.getTag());
                doStuff(iv_31, Card);
            }});
        iv_32.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                int Card = Integer.parseInt((String)view.getTag());
                doStuff(iv_32, Card);
            }});
        iv_33.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                int Card = Integer.parseInt((String)view.getTag());
                doStuff(iv_33, Card);
            }});
        iv_34.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                int Card = Integer.parseInt((String)view.getTag());
                doStuff(iv_34, Card);
            }});
    }
    private  void doStuff(ImageView iv , int card)
    {
        if(CardsCollection[card] == 11) {
            iv.setImageResource(image11);
        }
        else if(CardsCollection[card] == 12) {
            iv.setImageResource(image12);
        }
        else if(CardsCollection[card] == 13) {
            iv.setImageResource(image13);
        }
        else if(CardsCollection[card] == 14) {
            iv.setImageResource(image14);
        }
        else if(CardsCollection[card] == 15) {
            iv.setImageResource(image15);
        }
        else if(CardsCollection[card] == 16) {
            iv.setImageResource(image16);
        }
        else if(CardsCollection[card] == 21) {
            iv.setImageResource(image21);
        }
        else if(CardsCollection[card] == 22) {
            iv.setImageResource(image22);
        }
        else if(CardsCollection[card] == 23) {
            iv.setImageResource(image23);
        }
        else if(CardsCollection[card] == 24) {
            iv.setImageResource(image24);
        }
        else if(CardsCollection[card] == 25) {
            iv.setImageResource(image25);
        }
        else if(CardsCollection[card] == 26) {
            iv.setImageResource(image26);
        }

        if(cardNumber == 1)
        {
            firstCard = CardsCollection[card];
            if (firstCard > 20){
                firstCard = firstCard - 10;
            }
            cardNumber = 2;
            firstClick = card;

            iv.setEnabled(false);
        }
        else if (cardNumber == 2)
        {
            secondCard = CardsCollection[card];
            if (secondCard > 20){
                secondCard = secondCard - 10;
            }
            cardNumber = 1;
            secondClick = card;

            iv_11.setEnabled(false);
            iv_12.setEnabled(false);
            iv_13.setEnabled(false);
            iv_14.setEnabled(false);
            iv_21.setEnabled(false);
            iv_22.setEnabled(false);
            iv_23.setEnabled(false);
            iv_24.setEnabled(false);
            iv_31.setEnabled(false);
            iv_32.setEnabled(false);
            iv_33.setEnabled(false);
            iv_34.setEnabled(false);

            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    calculate();
                }
            },1000);
        }
    }
    private void calculate()
    {
        if (firstCard == secondCard) {
            successSong.start();
            if (firstClick == 0) {
                iv_11.setVisibility(View.INVISIBLE);
            } else if (firstClick == 1) {
                iv_12.setVisibility(View.INVISIBLE);
            } else if (firstClick == 2) {
                iv_13.setVisibility(View.INVISIBLE);
            } else if (firstClick == 3) {
                iv_14.setVisibility(View.INVISIBLE);
            } else if (firstClick == 4) {
                iv_21.setVisibility(View.INVISIBLE);
            } else if (firstClick == 5) {
                iv_22.setVisibility(View.INVISIBLE);
            } else if (firstClick == 6) {
                iv_23.setVisibility(View.INVISIBLE);
            } else if (firstClick == 7) {
                iv_24.setVisibility(View.INVISIBLE);
            } else if (firstClick == 8) {
                iv_31.setVisibility(View.INVISIBLE);
            } else if (firstClick == 9) {
                iv_32.setVisibility(View.INVISIBLE);
            } else if (firstClick == 10) {
                iv_33.setVisibility(View.INVISIBLE);
            } else if (firstClick == 11) {
                iv_34.setVisibility(View.INVISIBLE);
            }

            if (secondClick == 0) {
                iv_11.setVisibility(View.INVISIBLE);
            } else if (secondClick == 1) {
                iv_12.setVisibility(View.INVISIBLE);
            } else if (secondClick == 2) {
                iv_13.setVisibility(View.INVISIBLE);
            } else if (secondClick == 3) {
                iv_14.setVisibility(View.INVISIBLE);
            } else if (secondClick == 4) {
                iv_21.setVisibility(View.INVISIBLE);
            } else if (secondClick == 5) {
                iv_22.setVisibility(View.INVISIBLE);
            } else if (secondClick == 6) {
                iv_23.setVisibility(View.INVISIBLE);
            } else if (secondClick == 7) {
                iv_24.setVisibility(View.INVISIBLE);
            } else if (secondClick == 8) {
                iv_31.setVisibility(View.INVISIBLE);
            } else if (secondClick == 9) {
                iv_32.setVisibility(View.INVISIBLE);
            } else if (secondClick == 10) {
                iv_33.setVisibility(View.INVISIBLE);
            } else if (secondClick == 11) {
                iv_34.setVisibility(View.INVISIBLE);
            }

            if (turn == 1) {
                firstPlayerPoints++;
                points_p1.setText(player1 + " " + firstPlayerPoints);
            } else if (turn == 2) {
                secondPlayerPoints++;
                points_p2.setText(player2 + " " + secondPlayerPoints);
            }
        }else{
            failSong.start();
            iv_11.setImageResource(R.drawable.qm_icon);
            iv_12.setImageResource(R.drawable.qm_icon);
            iv_13.setImageResource(R.drawable.qm_icon);
            iv_14.setImageResource(R.drawable.qm_icon);
            iv_21.setImageResource(R.drawable.qm_icon);
            iv_22.setImageResource(R.drawable.qm_icon);
            iv_23.setImageResource(R.drawable.qm_icon);
            iv_24.setImageResource(R.drawable.qm_icon);
            iv_31.setImageResource(R.drawable.qm_icon);
            iv_32.setImageResource(R.drawable.qm_icon);
            iv_33.setImageResource(R.drawable.qm_icon);
            iv_34.setImageResource(R.drawable.qm_icon);

            if (turn == 1){
                turn = 2;
                points_p1.setTextColor(Color.GRAY);
                points_p2.setTextColor(Color.BLACK);
            }
            else if (turn == 2) {
                turn = 1;
                points_p1.setTextColor(Color.BLACK);
                points_p2.setTextColor(Color.GRAY);
            }
        }
        iv_11.setEnabled(true);
        iv_12.setEnabled(true);
        iv_13.setEnabled(true);
        iv_14.setEnabled(true);
        iv_21.setEnabled(true);
        iv_22.setEnabled(true);
        iv_23.setEnabled(true);
        iv_24.setEnabled(true);
        iv_31.setEnabled(true);
        iv_32.setEnabled(true);
        iv_33.setEnabled(true);
        iv_34.setEnabled(true);

        checkEnd();
    }
    private void checkEnd(){
        if(iv_11.getVisibility()==View.INVISIBLE &&
                iv_12.getVisibility()==View.INVISIBLE &&
                iv_13.getVisibility()==View.INVISIBLE &&
                iv_14.getVisibility()==View.INVISIBLE &&
                iv_21.getVisibility()==View.INVISIBLE &&
                iv_22.getVisibility()==View.INVISIBLE &&
                iv_23.getVisibility()==View.INVISIBLE &&
                iv_24.getVisibility()==View.INVISIBLE &&
                iv_31.getVisibility()==View.INVISIBLE &&
                iv_32.getVisibility()==View.INVISIBLE &&
                iv_33.getVisibility()==View.INVISIBLE &&
                iv_34.getVisibility()==View.INVISIBLE) {

            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(GameLogicActivity.this);
            alertDialogBuilder.setMessage("Game Over! \n Player 1: " + firstPlayerPoints + "\n Player 2: " + secondPlayerPoints)
                    .setCancelable(false).setPositiveButton("NEW", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                    finish();
                }
            }).setNegativeButton("EXIT", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            });
            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();
            winnerSong.start();
        }

    }
    private void frontOfCardResource()
    {
        image11 = R.drawable.bull_icon_101;
        image12 = R.drawable.cat_icon_101;
        image13 = R.drawable.chiken_icon_101;
        image14 = R.drawable.cow_icon_101;
        image15 = R.drawable.dog_icon_101;
        image16 = R.drawable.elephant_icon_101;

        image21 = R.drawable.bull_icon_201;
        image22 = R.drawable.cat_icon_201;
        image23 = R.drawable.chiken_icon_201;
        image24 = R.drawable.cow_icon_201;
        image25 = R.drawable.dog_icon_201;
        image26 = R.drawable.elephant_icon_201;

    }
}

